﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tibi
{
    internal class Food
    {
    }
    public void class Food
    {

    }

    public virtual void value()
    {
        Console.WriteLine("Az étel tápértéke");
    }
}
