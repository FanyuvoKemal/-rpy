﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tibi
{
    internal class Crab: Food
    {

    }
    public override void value()
    {

    }
}
