﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tibi
{
    internal class Turtle: Food
    {

    }

    public override void value()
    {

    }

}
