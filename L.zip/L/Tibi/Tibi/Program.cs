﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace Tibi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Food foods = new Food();
            Food crabFood = new Food();
            Food turtleFood = new Food(); 

            Food.value();
            Crab.value();
            Turtle.value();
        }
    }
}
